Assignment 0:- Design cycle accurate IEEE-754 floating point Discrete Event Simulator

Contents of Readme:
-Assumption on project
-Project Structure
-run steps
-Summary
-output format
-Sample output verification
-Acknowledgment, Discussion partner

Assumption 1 – Pipeline Structure
The assignment references a pipeline with four states: ISSUE, START, COMPLETE, and WRITEBACK.
Based on the provided test case, I implemented a 2-stage pipeline consisting of:
Execute Stage
Writeback Stage

The mapping of the four states to the pipeline is as follows:
ISSUE → Corresponds to the instruction’s arrival cycle.
START → The cycle when execution begins.
COMPLETE → The cycle when execution finishes (calculated as START + latency - 1).
WRITEBACK → Occurs exactly one cycle after COMPLETE.

Assumption 2 – Functional Unit Usage
All instructions must pass through the Functional Unit for execution.
The design assumes:
There is only one Functional Unit available for all instructions.
Instructions are executed strictly in order; the pipeline does not support out-of-order execution.

Assumption 3 - Handling Raw Hazards Only
only RAW Hazards creates stalls rest are not causing any stalls.

Assumption 4 – Register Initialization
The assignment specifies that all registers initially have a some value, but does not provide a mechanism to load custom values.
To allow meaningful testing across different scenarios, I have hardcoded initial register values as 1.1 .

Assumption 5 - Divisible By Zero Error
If DIV BY ZERO occures the program will terminate and error will be displayed on terminal but that instruction will be saved in CSV, JSON.


Project Structure:

    - `fp_simulator.cpp` – Entry point, simulation control
    - `input.txt` – List of Input Instructions
    - `MakeFile` - Automation file for program
    - `Output_csv.csv` - just everyday output file
    - `Output_csv_timeline.json` - just everyday output file (may use for visualisation)

 
How to Run :

1. Open MSYS2 UCRT64
   - Go to the Windows Start Menu and search for "MSYS2 UCRT64".
   - This environment includes the g++ compiler and make utility with the correct PATH configuration.

2. Navigate to the Project Directory
   - In the MSYS2 terminal, use the cd command to go to the folder containing fp_simulator.cpp and the Makefile.
   - Example (Desktop path):
     cd /c/Users/<your-username>/Desktop/fp_simulator

3. Build the Project
   - Run:
     make
   - This will compile the program and generate the executable.

4. Run the Simulator
   - Execute the simulator with the desired input and output files:
     ./fp_simulator <input_file.txt> <output_file.csv>
   - Example:
     ./fp_simulator input2.txt output2.csv

Project Summary: IEEE 754 Floating-Point Processor Simulator

This project is a cycle-accurate floating-point instruction simulator that models a pipelined processor executing IEEE 754 compliant operations. Built using a Discrete-Event Simulation (DES) approach, it accurately tracks instructions through the pipeline stages—Issue, Execution, Completion, and Write-back—while considering functional unit availability, timing, and data hazards. The simulator provides a detailed view of processor behavior, enabling analysis of performance metrics such as latency, throughput, and the impact of hazards on instruction scheduling.

The primary goal of this simulator is to replicate realistic hardware execution at the granularity of clock cycles, supporting multiple instruction types such as ADD.D, MUL.D, and DIV.D. It enables fine-grained analysis of key performance metrics, including latency, throughput, and both structural and data hazards. By simulating instruction flow in detail, the tool provides clear insights into how floating-point computations are scheduled and executed in a real-world CPU environment.


Output Format Details
The output follows the assignment’s specified format.
CSV Output:
- Each row contains the following fields:
  index, instruction, issue, start, complete, writeback, result
- The result is formatted to six decimal places.

JSON Output:
- The output is structured as an array of objects.
- Each object contains the fields:
  index, instruction, issue, start, complete, writeback, unit

Sample Output Verification
Below is an example to verify correct simulator behavior:
Input:
0 FADD.S R1 R2 R3

Expected CSV Output:
0,FADD.S R1 R2 R3,1,2,4,5,3.000000


Acknowledgement
This project was completed with the assistance of AI tools that includs Gemini and GPT. 
These tools provided explanations of concepts, debugging suggestions, and guidance on standard C++ practices.The logical decisions that I made where my own and I discussed it with GPT to ensure I am not thinking incorrectly.


Discussion Partner for the project was : CHIRAG KATHPALIA (2025MCS2098), a batchmate of MCS, with him I discussed about 2 stage cycle and about implementation of queue to ensure the correct execution of instructions.




