#include<bits/stdc++.h>
#include<limits>
#include <ctime>  // for time()
#include <cstdlib> // for rand()
using namespace std;

// creating a structure for instruction that contains all the necessary information
// such as index, operand, destination, registers, arrival time, issue time, start time
struct Instruction {
    int index;
    string operand;
    string dest, reg1, reg2;
   
    int arrival ;   
    int issue = -1 , start = -1 , complete = -1 , writeback = -1 ;
    double result;
    string address;

    bool error = false; 

};
int regIndex(const string &r) {
    return stoi(r.substr(1)); // R2 → 2
}

// Function to calculate latency based on the operand which is provided in the assignment0
// take string operand as input to get the latency corresponding to that input
unordered_map<string , int> latencyT={
    {"FADD.S" ,3} , {"FADD.D",5}, {"FSUB.S",3},{"FSUB.D",5},{"FMUL.S",4},{"FMUL.D",6},{"FDIV.S",10},{"FDIV.D",16},{"FMOV.S",1},{"FMOV.D",1}

};
int latency(string &operand){
    return latencyT.count(operand)?latencyT.at(operand):INT_MAX;
}
// this function does the execution of the instruction based on the operand and the values of registes basically airthmentic operations
// opertor1 it is the first operand which is a register value
// opertor2 it is the second operand which is a register value
// operand it is the operation to be performed
// the result of the operation
double execute(double opertor1 , double opertor2 , string operand, bool &zero){
    if(operand == "FADD.D"||operand == "FADD.S"){
        return (opertor1 + opertor2);
    }else if(operand == "FMUL.S"||operand == "FMUL.D"){
        return (opertor1*opertor2);
    }else if(operand == "FSUB.S"||operand == "FSUB.D"){
        return (opertor1-opertor2);
    }else if(operand == "FDIV.S" ||operand == "FDIV.D"){
        if(opertor2 == 0){
            cerr<<"err0r: divisibility by zero or infinite value"<<operand<<"\n";
            zero = true;
            return numeric_limits<double>::infinity();
        }
        return(opertor1/opertor2);
    }else if(operand=="FMOV.S"||operand=="FMOV.D") return opertor1;
    return 0.0;  // if the operand is not recognized or available in the instruction set return 0.0
}


int main(int argc , char* argv[]){

    if(argc < 3){
        cerr<<"use this:- ./fp_simulator <input_trace> <output_csv>\n";
        return 1;
    }

    string ip1 = argv[1];
    string outputCSV = argv[2];
    string outputJSON = outputCSV + "_timeline.json";

    // opening a file for reading the instructions 
    ifstream file(ip1);
    if(!file){
        cerr<< "error: not able to open input file";
        return 1;
    }
   
    vector<Instruction> in; //vector to store instructions
    string rLine;  // for reading line by line from thee file
    int idx = 0; //index for instruction
    while(getline(file, rLine)){
        if (rLine.empty()) continue; //skipping empty lines

        // reading line of the file
        stringstream ss(rLine);
        Instruction inst; //created instance for inst
        inst.index = idx++;      
        // using space as a delimiter to read the instruction
        ss >> inst.arrival >> inst.operand >> inst.dest >> inst.reg1 >> inst.reg2;
        //randomly assigning registers for destination and operands
      
       // cout<<inst.destValue<<" "<<inst.reg1Value<<" "<<inst.reg2Value<<"\n";
        //cout<<execute(inst.reg1Value, inst.reg2Value , inst.operand)<<" ";
        inst.address = inst.operand + " " + inst.dest + " " + inst.reg1 + " " + inst.reg2;
        in.push_back(inst);
       // cout<<latency(inst.operand);
    }

    vector<double> availReg(32 , 1.1); // vector to store the available registers initialized to 0.0

    vector<int> readyReg(32, 0); // vector to store the ready registers initialized to 0
    int aluReady = 0;

    //availReg[0] = 0;
    //availReg[2]=1.1; availReg[3]=2.0; availReg[5]=3.0;

   // srand(time(0));
    //for(int i=0; i<availReg.size(); i++){
    //availReg[i] = 1.0 + static_cast<double>(rand()) / RAND_MAX * 9.0;
    //}
    // zero var is for div zero error
    bool zero = false;

    // mainting a event queue
    queue<int> q;

    int countCycle = 0;

    int countIssued = 0;
    int n = in.size();
    while(countIssued< n){
        for(int i = 0 ; i<n; i++){
            //pushing index in queue for execeution
            if(in[i].arrival == countCycle){
                q.push(i);
            }
        }

        if(!q.empty()){
            int idx= q.front();
            Instruction &inst = in[idx];
            int rs1 = regIndex(inst.reg1);
           
            int rd = regIndex(inst.dest);

        
            double value1= availReg[rs1];

            // for mov operaation which req less latency 
            
            if(inst.operand == "FMOV.S"||inst.operand == "FMOV.D"){
                int tStart = max({countCycle , readyReg[rs1] , aluReady});

            inst.issue = countCycle;
            inst.start = tStart;
            inst.complete = tStart + latency(inst.operand) -1; //-1  latency calculation
            inst.writeback = inst.complete+1;

            double value1= availReg[rs1];

                inst.result = value1;
               // availReg[rs1] = 0;
               availReg[rd] = inst.result;
               readyReg[rd] = inst.writeback;
               aluReady = inst.writeback;
                

            }else{ 

                // for all other operations
                 int rs2 = regIndex(inst.reg2);
                int tStart = max({countCycle , readyReg[rs1] , readyReg[rs2] , aluReady});

            inst.issue = countCycle;
            inst.start = tStart;
            inst.complete = tStart + latency(inst.operand) -1;
            inst.writeback = inst.complete+1;

            double value1= availReg[rs1];
            double value2 = availReg[rs2];
            cout<<value1<<" , "<<value2<<"\n";
            inst.result = execute(value1 , value2 , inst.operand , zero);

            if(zero) inst.error = true;

            // if(isinf(inst.result)){
            //     cerr<<"excection stopped due to zero divisibility error"<<"\n";
            //     return 1;// stops the program
            // } 

            
            cout<<inst.result<<"\n";

            availReg[rd] = inst.result;
            readyReg[rd] = inst.writeback;
            aluReady = inst.writeback;
            //availReg[rs1] = 0;
            //availReg[rs2] = 0;


            }

            q.pop();
            countIssued++;
            
        }
        countCycle++;
    }


    ofstream output(outputCSV); // creating a csv file to write the output.
    
    //arranging the instructions as a comma separated value  
    for(int i = 0; i < in.size(); i++){
        output << in[i].index << "," << in[i].address <<","
        <<in[i].issue<<","<<in[i].start<<","<<in[i].complete<<","<<in[i].writeback<<",";
        if(in[i].error){
            output <<"infinity\n";

        }else
        output<< fixed << setprecision(6)<< in[i].result << endl;
    }
    output.close(); 
    file.close();
   
    //creting outputJson file to write the output in json format
    ofstream jsonFile(outputJSON); // output json data file

    // creating a json formated data for the display
    jsonFile << "[\n";
    for (int i = 0; i < in.size(); ++i){
        jsonFile << "  {\n";
        jsonFile << "    \"index\": " << in[i].index << ",\n";
        jsonFile << "    \"instr\": \"" << in[i].address << "\",\n";
        jsonFile << "    \"issue\": " << in[i].issue << ",\n";
        jsonFile << "    \"start\": " << in[i].start << ",\n";
        jsonFile << "    \"complete\": " << in[i].complete << ",\n";
        jsonFile << "    \"writeback\": " << in[i].writeback << ",\n";
        jsonFile << "    \"unit\": \"" << in[i].operand << "\"\n";
        jsonFile << "  }";
        if (i < in.size() - 1) {
            jsonFile << ",";
        }
        jsonFile << "\n";
    }
    jsonFile << "]\n";
    jsonFile.close();

   // system("python plot_timeline.py");

    return 0;
}