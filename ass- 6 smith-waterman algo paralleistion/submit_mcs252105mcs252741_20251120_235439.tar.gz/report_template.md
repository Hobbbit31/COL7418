# Report Template — Accelerator Leaderboard Submission


## Team: <2025mcs2105_2025mcs2741>


## 1. Problem description
- Application: GEMM (dense matrix multiply)

- Objective was to accelerate Dense General Matrix Multiplication(GEMM).
- Input matrices : Two square dense matrices of size N x N.

## 2. Baseline

- Description of baseline implementation (Python multiprocessing + NumPy) Baseline script implements a data-parallel matrix multiplication using Python's multiprocessing library to bypass the Global Interpreter Lock (GIL).

C = A*B

- It is splitting matrix A into P(#processes) set of rows , then a pool of P workers is created and each worker is assigned rows from A.

- They then works independently to calculate final matrix C by calling NumPy dot function, which in backend using BLAS library .

- Baseline Timings and Environment (CPU Model, Cores, OS):

- CPU Model: AMD RYZEN 7 7735HS with Radeon Graphics

- Cores: 8 ,16 threads

- CPU op-mode(s): 32bit, 64 bit

- Caches (sum of all): 
- L1d:256 KiB (8 instances)
- L1i:256 KiB (8 instances)
- L2:4 MiB (8 instances)
- L3:16 MiB (1 instance)

- NUMA:
- NUMA node(s):1
- NUMA node0 CPU(s):0-7

- Workstation provided: 
- Architecture:            x86_64
  CPU op-mode(s):        32-bit, 64-bit
  Address sizes:         46 bits physical, 48 bits virtual
  Byte Order:            Little Endian
- CPU(s):                  16
  On-line CPU(s) list:   0-15
- Vendor ID:               GenuineIntel
  Model name:            Intel(R) Xeon(R) W-2145 CPU @ 3.70GHz
    CPU family:          6
    Model:               85
    Thread(s) per core:  2
    Core(s) per socket:  8
    Socket(s):           1
- Caches (sum of all):     
  L1d:                   256 KiB (8 instances)
  L1i:                   256 KiB (8 instances)
  L2:                    8 MiB (8 instances)
  L3:                    11 MiB (1 instance)
- NUMA:                    
  NUMA node(s):          1
  NUMA node0 CPU(s):     0-15



- OS: Ubuntu 20.04 LTS

- Python Version: 3.8

- NumPy Version: 1.19.2


## 3. Optimizations implemented
- Multithreading with OpenMP

- OpenMP is a simple parallel programming API for C/C++. It uses pragmas to tell the compiler how to run code on multiple threads. It follows a fork–join model:

- Fork: Master thread creates worker threads.
- Parallel: Threads share the work.
- Join: Workers finish and terminate; master continues.

- OpenMP Features Used
- #pragma omp for : Splits the loop iterations across threads.

- schedule(static) : Divides iterations into equal fixed chunks before execution. Good when each iteration takes similar time.

- collapse(2) : Combines two nested loops into one large loop so OpenMP can distribute work more evenly.

- schedule(dynamic, 2) : Threads take work in chunks of size 2 at runtime. If a thread finishes early, it takes the next chunk. Prevents threads from sitting idle when work per iteration varies.


- Cache Blocking / Tiling in Our Optimized GEMM

- Naive GEMM has O(N³) complexity but poor memory access patterns, leading to cache thrashing. Each element in matrix A requires an entire column from matrix B, causing frequent cache evictions and memory stalls.

- We solve this with cache blocking (tiling), which divides the matrices into smaller MC × KC blocks. These tiles fit in the CPU cache, improving temporal locality and reducing memory access latency.

- Tiling in Our Code
- Our GEMM is divided into 3-level blocks:
- MC – Tile height
- KC – Inner dimension (shared by A and B)
- NC – Tile width

 - for jc in 0..N step NC
  - for ic in 0..N step MC
    - for pc in 0..N step KC

- By hit and trial method , we tried to tune it with various paramter later we towards a particular constant value on which our tiling approach was performing good NC:256 MC:128 KC:64 

-Each tile of A and B is processed with a SIMD microkernel, resulting in MC × NC blocks of C. This minimizes costly memory accesses.


- SIMD Optimization in Our GEMM Implementation

- To overcome the limits of scalar execution, our GEMM uses SIMD intrinsics. SIMD allows the CPU to operate on multiple data elements in a single instruction.
Our code detects CPU capabilities at runtime (via CPUID + XGETBV) and selects the best available instruction set:

- AVX-512 microkernel (8×8)
- AVX2 microkernel (4×4)

- This ensures maximum performance on any machine.

1. AVX2 (Used when AVX-512 is not available)
- SIMD Width

- 256-bit YMM registers (YMM0–YMM15)
- Can process 4 double-precision values at once.

- Data Types Used
- __m256d → 256-bit vector holding 4 doubles
- __m128d → 128-bit vector holding 2 doubles (used for edge reduction)

- Key Intrinsics in Our 4×4 Microkernel
- _mm256_loadu_pd()
- Loads 4 doubles from memory into a YMM register.

- _mm256_fmadd_pd(a, b, c)
- Computes (a * b) + c for all 4 doubles.
- Core of the microkernel.

- _mm256_broadcast_sd()
- Broadcasts a single double from A across the 4 lanes.

- _mm256_storeu_pd()
- Stores the result back to C.
These intrinsics allow our 4×4 kernel to update 16 values of C efficiently.

2. AVX-512 (Used when compiled with AVX-512 support)
- SIMD Width
- 512-bit ZMM registers (ZMM0–ZMM31)
- Can process 8 double-precision values at once.

- Data Types Used
- __m512d → 512-bit vector holding 8 doubles
- Key Intrinsics in Our 8×8 Microkernel

- _mm512_loadu_pd()
- Loads 8 doubles from memory.

- _mm512_set1_pd(val)
- Broadcasts a single double from A across 8 lanes.

- _mm512_fmadd_pd(a, b, c)
- Computes (a*b) + c for all 8 elements.

- _mm512_storeu_pd()
- Stores updated rows back into C.
- This gives us an efficient 8×8 microkernel operating purely in registers.

- Memory-Aligned Matrices

- Our GEMM uses aligned memory because SIMD loads work fastest when data starts at specific byte boundaries.

- AVX-512 = 512 bits = 64 bytes → needs 64-byte alignment
- AVX2 = 256 bits = 32 bytes → needs 32-byte alignment
- Aligned memory prevents split-line loads and keeps vector instructions efficient.

- In our code we use:
- A = (double*) aligned_malloc(size, 64);
- B = (double*) aligned_malloc(size, 64);
- C = (double*) aligned_malloc(size, 64);

- Loop unrolling in our kernels

- We unroll the innermost K-loop to fill vector registers and use FMA on multiple accumulators.

- AVX2 (4×4 microkernel, 256-bit)
- Unroll factor: 4 (process 4 doubles per vector).
- Pattern: load bvec as __m256d, broadcast each scalar a into a vector, then FMA into c accumulators.

for (int k = 0; k < K; ++k) {
    __m256d bvec = _mm256_loadu_pd(&B_tile[k * ldb]);       
    double a0 = A_tile[0 * lda + k];
    double a1 = A_tile[1 * lda + k];
    double a2 = A_tile[2 * lda + k];
    double a3 = A_tile[3 * lda + k];

    c0 = _mm256_fmadd_pd(_mm256_broadcast_sd(&a0), bvec, c0);
    c1 = _mm256_fmadd_pd(_mm256_broadcast_sd(&a1), bvec, c1);
    c2 = _mm256_fmadd_pd(_mm256_broadcast_sd(&a2), bvec, c2);
    c3 = _mm256_fmadd_pd(_mm256_broadcast_sd(&a3), bvec, c3);
}

- similarly it is done for avx512 with a scaling factor of 8.


## 4. Experimental methodology
- Commands Used to Run Baseline and Optimized:

- Baseline Run: python3 baseline/gemm_baseline.py or ./run.sh baseline 

- Optimized Run: ./optimized/gemm_opt n t (where n = size of row/col and t = no of threads) or ./run.sh optimized

- Number of Runs, How Median Chosen, Perf Counters Collected:

- For each configuration (baseline and optimized), 10 runs were performed.
- The median runtime was chosen to mitigate the impact of outliers.
- Perf counters such as cache misses, IPC, and bandwidth were collected using: perf stat -ddd ./optimized/gemm_opt n t



## 5. Results
- Tables and Plots:
- Runtime Comparison:
-AVX512:(This is the workstation provided to us)

| N     | Threads | Time_o(s) | Checksum      | Gflops  | Time_B(s)  | Speedup | L1d missrate | L1i missrate | L3 missrate | IPC  |1
| ----- | ------- | ----------| ------------- | --------| -----------| --------| -------------| -------------| ------------| ---- |
| 1000  | 1       | 0.001933  | 450           | 5.17    | 0.002975   | 41.41   | 0.45         |              | 25.71       | 1.31 |
| 2000  | 1       | 0.004015  | 884           | 9.96    | 0.016564   | 28.19   | 1.85         |              | 28.43       | 1.62 |
| 3000  | 1       | 0.007712  | 1353          | 11.67   | 0.040288   | 26.97   | 4.09         |              | 28.07       | 1.71 |
| 4000  | 1       | 0.012528  | 1755          | 12.71   | 0.068028   | 27.99   | 3.56         |              | 35.55       | 2.16 |
| 5000  | 1       | 0.019600  | 2215          | 12.76   | 0.111254   | 22.54   | 6.47         |              | 35.94       | 2.31 |
| 6000  | 1       | 0.026895  | 2681          | 13.54   | 0.168613   | 20.92   | 9.64         |              | 31.41       | 2.39 |
| 7000  | 1       | 0.034758  | 3142          | 14.11   | 0.232489   | 20.60   | 9.74         |              | 34.54       | 2.36 |
| 8000  | 1       | 0.044084  | 3624          | 14.20   | 0.307011   | 25.22   | 10.07        |              | 33.57       | 2.52 |
| 9000  | 1       | 0.054719  | 4132          | 14.75   | 0.403772   | 20.03   | 11.02        |              | 29.47       | 2.59 |
| 10000 | 1       | 0.065767  | 4504          | 15.21   | 0.500460   | 36.29   | 11.43        |              | 32.77       | 2.45 |
| 20000 | 1       | 0.245559  | 9054          | 16.40   | 1.416112   | 41.41   | 12.34        |              | 25.71       | 2.77 |
| 30000 | 1       | 0.536241  | 13662         | 16.30   | 3.431124   | 28.19   | 12.87        |              | 28.43       | 2.71 |
| 40000 | 1       | 0.933749  | 18175         | 17.85   | 4.059115   | 26.97   | 12.95        |              | 28.07       | 2.72 |
| 50000 | 1       | 1.154004  | 22708         | 21.66   | 8.775323   | 27.99   | 12.98        |              | 35.55       | 2.70 |
| 60000 | 1       | 1.550962  | 27257         | 23.03   | 29.739124  | 22.54   | 12.95        |              | 35.94       | 2.64 |
| 70000 | 1       | 2.282202  | 31874         | 21.62   | 57.529457  | 20.92   | 12.99        |              | 31.41       | 2.67 |
| 80000 | 1       | 2.764410  | 36439         | 23.58   | 164.864575 | 20.60   | 13.04        |              | 34.54       | 2.55 |
| 90000 | 1       | 3.472731  | 40892         | 23.28   | 203.638544 | 25.22   | 13.03        |              | 33.57       | 2.53 |
| 100000| 1       | 4.121545  | 45646         | 24.27   | 293.467894 | 20.03   | 12.96        |              | 29.47       | 2.67 |
| 200000| 1       | 16.499778 | 90791         | 24.25   | 243.570031 | 36.29   | 12.89        |              | 32.77       | 2.64 |



| N     | Threads | Time_o(s) | Checksum      | Gflops  | Time_B(s)  | Speedup | L1d missrate | L1i missrate | L3 missrate | IPC  |
| ----- | ------- | ----------| ------------- | --------| -----------| --------| -------------| -------------| ------------| ---- |
| 1000  | 8       | 0.003737  | 450           | 2.68    | 0.002975   | 41.41   | 5.66         |              | 25.71       | 0.31 |
| 2000  | 8       | 0.006756  | 884           | 6.15    | 0.016564   | 28.19   | 5.25         |              | 28.43       | 0.37 |
| 3000  | 8       | 0.011647  | 1353          | 7.96    | 0.040288   | 26.97   | 6.35         |              | 28.07       | 0.32 |
| 4000  | 8       | 0.015528  | 1755          | 10.31   | 0.068028   | 27.99   | 6.22         |              | 35.55       | 0.39 |
| 5000  | 8       | 0.020281  | 2215          | 11.96   | 0.111254   | 22.54   | 6.17         |              | 35.94       | 0.48 |
| 6000  | 8       | 0.023040  | 2681          | 15.54   | 0.168613   | 20.92   | 5.58         |              | 31.41       | 0.62 |
| 7000  | 8       | 0.031457  | 3142          | 15.57   | 0.232489   | 20.60   | 7.14         |              | 34.54       | 0.51 |
| 8000  | 8       | 0.032231  | 3624          | 19.20   | 0.307011   | 25.22   | 6.07         |              | 33.57       | 0.61 |
| 9000  | 8       | 0.039353  | 4132          | 20.75   | 0.403772   | 20.03   | 6.46         |              | 29.47       | 0.62 |
| 10000 | 8       | 0.044518  | 4504          | 22.43   | 0.500460   | 36.29   | 6.67         |              | 32.77       | 0.60 |
| 20000 | 8       | 0.125559  | 9054          | 32.46   | 1.416112   | 41.41   | 7.63         |              | 25.71       | 0.81 |
| 30000 | 8       | 0.246241  | 13662         | 37.30   | 3.431124   | 28.19   | 9.36         |              | 28.43       | 0.79 |
| 40000 | 8       | 0.393749  | 18175         | 40.85   | 4.059115   | 26.97   | 10.43        |              | 28.07       | 0.87 |
| 50000 | 8       | 0.566550  | 22708         | 44.88   | 8.775323   | 27.99   | 10.98        |              | 35.55       | 1.01 |
| 60000 | 8       | 0.768904  | 27257         | 46.03   | 29.739124  | 22.54   | 11.42        |              | 35.94       | 1.05 |
| 70000 | 8       | 0.992202  | 31874         | 49.62   | 57.529457  | 20.92   | 11.67        |              | 31.41       | 1.06 |
| 80000 | 8       | 1.174410  | 36439         | 54.58   | 164.864575 | 20.60   | 11.73        |              | 34.54       | 1.07 |
| 90000 | 8       | 1.362731  | 40892         | 59.67   | 203.638544 | 25.22   | 11.90        |              | 33.57       | 1.12 |
| 100000| 8       | 1.411545  | 45646         | 70.04   | 293.467894 | 20.03   | 11.96        |              | 29.47       | 1.14 |
| 200000| 8       | 5.308977  | 90791         | 75.47   | 243.570031 | 36.29   | 12.27        |              | 32.77       | 1.22 |



N     |threads|   time   |checksum|gflops|l1d misses|l1i misses|IPC
1000 | 8     | 0.003784 | 450     | 2.64 | 4.83     | 0.19     | 0.50
2000 | 8     | 0.007013 | 884     | 5.70 | 5.41     | 0.07     | 0.42
3000 | 8     | 0.012279 | 1353     | 7.33 | 6.57     | 0.10     | 0.33
4000 | 8     | 0.015237 | 1755     | 10.50 | 5.43     | 0.09     | 0.44
5000 | 8     | 0.018298 | 2215     | 13.66 | 5.11     | 0.09     | 0.54
6000 | 8     | 0.022384 | 2681     | 16.08 | 5.34     | 0.10     | 0.62
7000 | 8     | 0.027972 | 3142     | 17.52 | 6.47     | 0.12     | 0.56
8000 | 8     | 0.033081 | 3624     | 19.35 | 6.13     | 0.06     | 0.62
9000 | 8     | 0.040978 | 4132     | 19.77 | 6.53     | 0.06     | 0.60
10000 | 8     | 0.046328 | 4504     | 21.59 | 6.09     | 0.07     | 0.66
20000 | 8     | 0.123632 | 9054     | 32.35 | 7.39     | 0.07     | 0.83
30000 | 8     | 0.245957 | 13662     | 36.59 | 9.30     | 0.07     | 0.89
40000 | 8     | 0.329538 | 18175     | 48.55 | 10.44     | 0.12     | 0.95
50000 | 8     | 0.431709 | 22708     | 57.91 | 11.11     | 0.08     | 0.99
60000 | 8     | 0.553735 | 27257     | 65.01 | 11.32     | 0.09     | 1.07
70000 | 8     | 0.760283 | 31874     | 64.45 | 11.61     | 0.11     | 1.05
80000 | 8     | 0.942328 | 36439     | 67.92 | 11.75     | 0.14     | 1.11
90000 | 8     | 1.168393 | 40892     | 69.33 | 11.90     | 0.13     | 1.13
100000 | 8     | 1.415527 | 45646     | 70.65 | 11.98     | 0.13     | 1.15

1000 | 1     | 0.001503 | 450     | 6.65 | 0.06     | NA     | 2.26
2000 | 1     | 0.004111 | 884     | 9.73 | 1.00     | 0.06     | 1.95
3000 | 1     | 0.008788 | 1353     | 10.24 | 5.85     | 0.02     | 2.47
4000 | 1     | 0.013287 | 1755     | 12.04 | 7.04     | 0.06     | 2.14
5000 | 1     | 0.018710 | 2215     | 13.36 | 5.78     | 0.04     | 2.44
6000 | 1     | 0.027203 | 2681     | 13.23 | 9.29     | 0.03     | 2.47
7000 | 1     | 0.034342 | 3142     | 14.27 | 8.78     | 0.02     | 2.52
8000 | 1     | 0.043359 | 3624     | 14.76 | 10.05     | 0.02     | 2.58
9000 | 1     | 0.055943 | 4132     | 14.48 | 10.97     | 0.04     | 2.57
10000 | 1     | 0.065050 | 4504     | 15.37 | 11.17     | 0.02     | 2.67
20000 | 1     | 0.242847 | 9054     | 16.47 | 12.37     | 0.06     | 2.77
30000 | 1     | 0.463710 | 13662     | 19.41 | 12.79     | 0.12     | 2.69
40000 | 1     | 0.641615 | 18175     | 24.94 | 13.00     | 0.25     | 2.72
50000 | 1     | 1.047694 | 22708     | 23.86 | 12.90     | 0.19     | 2.60
60000 | 1     | 1.436487 | 27257     | 25.06 | 12.92     | 0.30     | 2.71
70000 | 1     | 1.968002 | 31874     | 24.90 | 12.98     | 0.34     | 2.68
80000 | 1     | 2.561140 | 36439     | 24.99 | 13.01     | 0.37     | 2.69
90000 | 1     | 3.328058 | 40892     | 24.34 | 13.08     | 0.21     | 2.64
100000 | 1     | 4.208640 | 45646     | 23.76 | 13.02     | 0.33     | 2.58

1000 | 2     | 0.001641 | 450     | 6.09 | 0.27     | NA     | 3.85
2000 | 2     | 0.005127 | 884     | 7.80 | 0.89     | 0.04     | 2.51
3000 | 2     | 0.008116 | 1353     | 11.09 | 5.97     | 0.02     | 2.60
4000 | 2     | 0.013933 | 1755     | 11.48 | 7.18     | 0.01     | 1.77
5000 | 2     | 0.019271 | 2215     | 12.97 | 5.88     | 0.04     | 2.36
6000 | 2     | 0.026732 | 2681     | 13.47 | 9.04     | 0.04     | 2.34
7000 | 2     | 0.034737 | 3142     | 14.11 | 8.82     | 0.04     | 2.49
8000 | 2     | 0.043100 | 3624     | 14.85 | 10.37     | 0.09     | 2.57
9000 | 2     | 0.053543 | 4132     | 15.13 | 10.95     | 0.03     | 2.59
10000 | 2     | 0.065467 | 4504     | 15.27 | 11.21     | 0.02     | 2.65
20000 | 2     | 0.243153 | 9054     | 16.45 | 12.36     | 0.05     | 2.76
30000 | 2     | 0.430301 | 13662     | 20.92 | 12.86     | 0.14     | 2.74
40000 | 2     | 0.639308 | 18175     | 25.03 | 13.08     | 0.15     | 2.72
50000 | 2     | 1.023417 | 22708     | 24.43 | 13.05     | 0.18     | 2.68
60000 | 2     | 1.524543 | 27257     | 23.61 | 12.95     | 0.35     | 2.57
70000 | 2     | 2.113617 | 31874     | 23.18 | 12.98     | 0.33     | 2.53
80000 | 2     | 2.651360 | 36439     | 24.14 | 12.99     | 0.33     | 2.63
90000 | 2     | 3.363715 | 40892     | 24.08 | 12.96     | 0.31     | 2.59
100000 | 2     | 4.248614 | 45646     | 23.54 | 12.93     | 0.37     | 2.55





- Microarchitecture counters: L1/L2/L3 misses,  IPC


## 6. Analysis

- GFLOPS:
-As N increases, total execution time naturally rises for both the baseline and our optimized version.
- However, the tiled + SIMD (AVX2/AVX-512) implementation runs much faster, so GFLOPS increases significantly.
- Since GFLOPS is inversely proportional to time, our optimized kernel reaches high performance (~115–120 GFLOPS) for large N due to:

- vectorized microkernels (4×4 AVX2 or 8×8 AVX-512),
- cache-friendly tiling,
- reduced memory stalls.

- L1 Misses:
- As N grows, L1 data misses increase, but tiling keeps the working set small:
- In AVX2, L1 misses fluctuate because 4×4 tiles stress L1 more frequently.
- In AVX-512, the miss pattern stabilizes after a point since 8×8 tiles reuse more data per load.

Typical L1 D-cache miss rates observed:
- AVX2: ~10–12%
- AVX-512: ~10–18% (slightly higher due to wider loads and more bandwidth demand)

- Memory Bandwidth:
- With fewer threads, each core has more available cache and memory bandwidth, giving high IPC per core.
- As thread count increases:
- Overall GFLOPS improves because more cores execute tiles in parallel.
- But threads begin competing for the same cache and memory resources.
- This reduces per-core IPC and increases cache/memory pressure.
- This behavior matches our tiled GEMM, where A/B blocks must be streamed repeatedly from memory.

- Further Improvements:
- Based on our implementation, the following optimizations can push performance further:
- Better software prefetching inside the microkernels to hide memory latency.
- NUMA-aware data placement (first-touch policy, node-local allocation).
- Improving OpenMP scheduling (e.g., static chunking) for more consistent load balancing.
- Refining block sizes (MC, KC, NC) to better match L1/L2/L3 cache capacities.
- Packing matrices (especially B) to improve spatial locality and remove strided loads.

## 7. Reproducibility

- Operating System:
- Linux (Ubuntu 22.04) or Windows Subsystem for Linux (WSL2).
- CPU: An x86_64 processor with support for AVX2, FMA, and AVX512F.
- Compiler: g++ (GNU Compiler Collection) 10.0 or newer (or clang++) with C++17 support.
- Libraries: OpenMP

- Compilation
- The code must be compiled with optimizations, OpenMP support, and the specific target architecture flags enabled.
- Bash : g++ -o gemm_opt gemm_opt.cpp -O3 -fopenmp -march=native
- O3: Enables high-level compiler optimizations.
- fopenmp: Links the OpenMP runtime.
- march=native: Ensures the compiler can generate the vectorized code for the target machine.
- The script usage is: ./gemm_opt N num_threads