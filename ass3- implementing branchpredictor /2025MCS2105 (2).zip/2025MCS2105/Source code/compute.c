#include <stdio.h>

int main() {
    int a = 1, b = 2, c = 3, d = 4;

    for (int i = 0; i < 300000; i++) {
        a = a + b;
        b = b - c;
        c = c * d;
        d = d ^ a;       // bitwise XOR
        a = (a << 1) | (a >> 1);  // simple rotate-ish shift
    }

    int result = a + b + c + d;
    printf("Compute result: %d\n", result);
    return 0;
}
