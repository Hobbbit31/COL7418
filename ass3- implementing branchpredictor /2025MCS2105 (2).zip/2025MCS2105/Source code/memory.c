#include <stdio.h>
#include <stdlib.h>

int main() {
    int N = 300000;
    double *A = malloc(N * sizeof(double));
    double *B = malloc(N * sizeof(double));
    double *C = malloc(N * sizeof(double));

    for (int i = 0; i < N; i++) {
        B[i] = i * 0.5;
        C[i] = i * 0.25;
    }

    for (int i = 0; i < N; i++) {
        A[i] = B[i] + 2.0 * C[i];
    }

    double sum = 0.0;
    for (int i = 0; i < N; i++) sum += A[i];
    printf("Stream sum: %.2f\n", sum);

    free(A); free(B); free(C);
    return 0;
}
