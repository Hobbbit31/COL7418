#include <stdio.h>
#include <stdlib.h>

struct Node { struct Node *next; };

int main() {
    int N = 300000;
    struct Node *nodes = malloc(N * sizeof(struct Node));
    for (int i = 0; i < N - 1; i++) nodes[i].next = &nodes[i + 1];
    nodes[N - 1].next = &nodes[0];  // circular

    struct Node *p = &nodes[0];
    for (int i = 0; i < 300000; i++) p = p->next;

    printf("Pointer chase finished at: %p\n", (void*)p);
    free(nodes);
    return 0;
}
