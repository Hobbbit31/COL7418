#!/usr/bin/env python3
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

# ========== CONFIG ==========
FILE_NAME = 'summary.csv'          # or '/mnt/data/summary.csv'
OUTPUT_DIR = Path('plots')         # all images go here
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def save_fig(filename, dpi=160):
    out = OUTPUT_DIR / filename
    plt.tight_layout()
    plt.savefig(out, dpi=dpi, bbox_inches='tight')
    plt.close()
    print(f"Saved: {out}")

# ========== LOAD ==========
try:
    df = pd.read_csv(FILE_NAME)
except FileNotFoundError:
    raise FileNotFoundError(f"Error: The file '{FILE_NAME}' was not found.")

numeric_cols = [
    'ROB','issue','IPC',
    'L1D_AMAT','L1I_AMAT','L2_AMAT',
    'L1D_MPKI','L1I_MPKI','L2_MPKI',
    'L1D_hit_rate','L1I_hit_rate','L2_hit_rate',
    'branch_mispred_rate','stall_frac_of_simTicks',
    'l1A','l2A'
]
for col in numeric_cols:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')

required_cols = ['workload','branchPred','memDep']
missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"Missing required columns: {missing}")

# normalize branchPred
def _norm_bpred(x: str) -> str:
    s = str(x).strip().lower()
    if "tournament" in s or s == "tour": return "tournament"
    if s in {"off","0","disabled","disable"} or "off" in s: return "off"
    if s in {"on","1","enabled","enable"} or "on" in s: return "on"
    return s
df['branchPred'] = df['branchPred'].apply(_norm_bpred)

present_numeric_cols = [c for c in numeric_cols if c in df.columns]
df.dropna(subset=present_numeric_cols + required_cols, inplace=True)
df['Workload_MemDep'] = df['workload'].astype(str) + ' (' + df['memDep'].astype(str) + ')'

# ========== HELPERS ==========
def get_x_positions(x, group_index, total_groups, bar_width):
    return x + (group_index - (total_groups - 1) / 2) * bar_width

def safe_values_by_workload(subset, workloads, value_col):
    return subset.set_index('workload').reindex(workloads)[value_col].values

def _aligned(subset, workloads, value_col):
    return subset.set_index('workload').reindex(workloads)[value_col].values

def _line_plot_off_vs_tournament(pivot_df, workloads, value_col, title, ylabel, outfile):
    fig, ax = plt.subplots(figsize=(10,5))
    found = False
    for pred in ("off","tournament"):
        sub = pivot_df[pivot_df["branchPred"] == pred]
        if sub.empty:
            continue
        ax.plot(workloads, _aligned(sub, workloads, value_col), marker='o', label=pred)
        found = True
    if not found:
        print(f"WARNING: no 'off' or 'tournament' data for {title}")
        plt.close(); return
    ax.set_xlabel("Workload"); ax.set_ylabel(ylabel); ax.set_title(title)
    ax.legend(title="Branch predictor")
    plt.xticks(rotation=45, ha='right')
    save_fig(outfile)

# ========== PLOTS ==========
def plot_amat_logscale(df):
    needed = {'workload','L1D_AMAT','L1I_AMAT','L2_AMAT'}
    if not needed.issubset(df.columns): return
    d = df.melt(id_vars=['workload'],
                value_vars=['L1D_AMAT','L1I_AMAT','L2_AMAT'],
                var_name='Cache_Level', value_name='AMAT')
    d['Cache_Level'] = d['Cache_Level'].str.replace('_AMAT','', regex=False)
    g = d.groupby(['workload','Cache_Level'])['AMAT'].mean().reset_index()
    fig, ax = plt.subplots(figsize=(10,6))
    levels = list(g['Cache_Level'].unique())
    workloads = list(g['workload'].unique())
    x = np.arange(len(workloads)); bw = 0.25
    for i, lvl in enumerate(levels):
        sub = g[g['Cache_Level']==lvl]
        vals = safe_values_by_workload(sub, workloads, 'AMAT')
        vals = np.where(np.isnan(vals) | (vals<=0), np.nan, vals)
        ax.bar(get_x_positions(x,i,len(levels),bw), vals, bw, label=lvl)
    ax.set_title('Average AMAT by Workload and Cache Level (Log Scale)')
    ax.set_xlabel('Workload'); ax.set_ylabel('AMAT')
    ax.set_yscale('log'); ax.set_xticks(x); ax.set_xticklabels(workloads)
    ax.legend(title='Cache Level'); ax.grid(axis='y', linestyle='--', alpha=0.6)
    save_fig('amat_by_workload_level_logscale.png')

def plot_ipc_vs_rob(df):
    needed = {'workload','issue','ROB','IPC','branchPred'}
    if not needed.issubset(df.columns): return
    base = df[df['branchPred']=='tournament'].copy()
    if base.empty: return
    g = base.groupby(['workload','issue','ROB'])['IPC'].mean().reset_index()
    plt.figure(figsize=(12,6))
    for (workload, issue), grp in g.sort_values('ROB').groupby(['workload','issue']):
        plt.plot(grp['ROB'], grp['IPC'], marker='o', label=f'{workload} (Issue {int(issue)})')
    plt.title('IPC vs ROB (BranchPred: Tournament)')
    plt.xlabel('ROB'); plt.ylabel('IPC')
    plt.xticks(sorted(g['ROB'].unique()))
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend(title='Workload & Issue')
    save_fig('ipc_vs_rob_generated.png')

def plot_ipc_vs_width(df):
    needed = {'workload','ROB','issue','IPC','branchPred'}
    if not needed.issubset(df.columns): return
    base = df[df['branchPred']=='tournament'].copy()
    if base.empty: return
    g = base.groupby(['workload','ROB','issue'])['IPC'].mean().reset_index()
    plt.figure(figsize=(12,6))
    for (workload, rob), grp in g.sort_values('issue').groupby(['workload','ROB']):
        plt.plot(grp['issue'], grp['IPC'], marker='o', label=f'{workload} (ROB {int(rob)})')
    plt.title('IPC vs Issue Width (BranchPred: Tournament)')
    plt.xlabel('Issue Width'); plt.ylabel('IPC')
    plt.xticks(sorted(g['issue'].unique()))
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend(title='Workload & ROB')
    save_fig('ipc_vs_width_generated.png')

def plot_mpki_by_level(df):
    needed = {'workload','memDep','L1D_MPKI','L1I_MPKI','L2_MPKI'}
    if not needed.issubset(df.columns): return
    g0 = df.groupby(['workload','memDep'])[['L1D_MPKI','L1I_MPKI','L2_MPKI']].mean().reset_index()
    d = g0.melt(id_vars=['workload','memDep'],
                value_vars=['L1D_MPKI','L1I_MPKI','L2_MPKI'],
                var_name='Cache_Level', value_name='MPKI')
    d['Cache_Level'] = d['Cache_Level'].str.replace('_MPKI','', regex=False)
    fig, ax = plt.subplots(figsize=(12,6))
    levels = list(d['Cache_Level'].unique())
    workloads = sorted(d['workload'].unique())
    memdeps = list(d['memDep'].unique())
    x = np.arange(len(workloads)); bw = 0.15
    gi = 0; total = len(levels)*len(memdeps)
    for lvl in levels:
        for dep in memdeps:
            sub = d[(d['Cache_Level']==lvl)&(d['memDep']==dep)]
            vals = safe_values_by_workload(sub, workloads, 'MPKI')
            vals = np.nan_to_num(vals, nan=0.0)
            ax.bar(get_x_positions(x, gi, total, bw), vals, bw, label=f'{lvl} ({dep})')
            gi += 1
    ax.set_title('Average MPKI by Workload, Cache Level, memDep')
    ax.set_xlabel('Workload'); ax.set_ylabel('MPKI')
    ax.set_xticks(x); ax.set_xticklabels(workloads)
    ax.legend(loc='upper right'); ax.grid(axis='y', linestyle='--', alpha=0.6)
    save_fig('mpki_by_bench_memdep_generated.png')

def plot_bp_miss_vs_ipc(df):
    needed = {'branch_mispred_rate','IPC','Workload_MemDep'}
    if not needed.issubset(df.columns): return
    cats = sorted(df['Workload_MemDep'].astype(str).unique())
    codes = df['Workload_MemDep'].astype('category').cat.codes
    plt.figure(figsize=(10,6))
    sc = plt.scatter(df['branch_mispred_rate'], df['IPC'], c=codes, alpha=0.8, s=100)
    plt.title('IPC vs Branch Misprediction Rate (by Workload & memDep)')
    plt.xlabel('Branch Misprediction Rate'); plt.ylabel('IPC')
    plt.grid(True, linestyle='--', alpha=0.6)
    handles, _ = sc.legend_elements(num=len(cats))
    plt.legend(handles, cats, title='Workload (memDep)', loc='upper right')
    save_fig('bp_miss_vs_ipc_workload_memdep_final_in_plot.png')

def plot_stall_by_bp(df):
    needed = {'branchPred','stall_frac_of_simTicks'}
    if not needed.issubset(df.columns): return
    g = df.groupby('branchPred')['stall_frac_of_simTicks'].mean().reset_index()
    plt.figure(figsize=(7,5))
    plt.bar(g['branchPred'], g['stall_frac_of_simTicks'])
    plt.title('Average Stall Fraction by Branch Predictor')
    plt.xlabel('Branch Predictor'); plt.ylabel('Stall Fraction of simTicks')
    plt.grid(axis='y', linestyle='--', alpha=0.6)
    save_fig('stall_frac_by_bp.png')

def plot_stall_vs_width(df):
    needed = {'issue','stall_frac_of_simTicks'}
    if not needed.issubset(df.columns): return
    g = df.groupby('issue')['stall_frac_of_simTicks'].mean().reset_index()
    plt.figure(figsize=(7,5))
    plt.plot(g['issue'], g['stall_frac_of_simTicks'], marker='o', linestyle='-')
    plt.title('Average Stall Fraction vs Issue Width')
    plt.xlabel('Issue Width'); plt.ylabel('Stall Fraction of simTicks')
    plt.xticks(sorted(g['issue'].unique()))
    plt.grid(True, linestyle='--', alpha=0.6)
    save_fig('stall_frac_vs_width.png')

def plot_hitrate_by_workload(df):
    needed = {'workload','L1D_hit_rate','L1I_hit_rate','L2_hit_rate'}
    if not needed.issubset(df.columns): return
    d = df.melt(id_vars=['workload'],
                value_vars=['L1D_hit_rate','L1I_hit_rate','L2_hit_rate'],
                var_name='Cache_Level', value_name='Hit_Rate')
    d['Cache_Level'] = d['Cache_Level'].str.replace('_hit_rate','', regex=False)
    g = d.groupby(['workload','Cache_Level'])['Hit_Rate'].mean().reset_index()
    fig, ax = plt.subplots(figsize=(10,6))
    levels = list(g['Cache_Level'].unique())
    workloads = list(g['workload'].unique())
    x = np.arange(len(workloads)); bw = 0.25
    for i, lvl in enumerate(levels):
        sub = g[g['Cache_Level']==lvl]
        vals = safe_values_by_workload(sub, workloads, 'Hit_Rate')
        vals = np.nan_to_num(vals, nan=0.0)
        ax.bar(get_x_positions(x, i, len(levels), bw), vals, bw, label=lvl)
    ax.set_title('Average Cache Hit Rate by Workload and Cache Level')
    ax.set_xlabel('Workload'); ax.set_ylabel('Hit Rate')
    ax.set_xticks(x); ax.set_xticklabels(workloads)
    ax.legend(title='Cache Level'); ax.grid(axis='y', linestyle='--', alpha=0.6)
    save_fig('hitrate_by_workload_level.png')

# ===== UPDATED: one PNG per workload =====
def plot_ipc_vs_l1d_associativity(df):
    needed = {'l1A','workload','IPC'}
    if not needed.issubset(df.columns):
        return
    g = df.groupby(['l1A','workload'])['IPC'].mean().reset_index()
    for workload, grp in g.sort_values('l1A').groupby('workload'):
        plt.figure(figsize=(8,5))
        plt.plot(grp['l1A'], grp['IPC'], marker='o', linestyle='-')
        plt.title(f'IPC vs L1D Associativity — {workload}')
        plt.xlabel('L1D Associativity (l1A)')
        plt.ylabel('IPC (Instructions Per Cycle)')
        plt.xticks(sorted(grp['l1A'].unique()))
        plt.grid(True, linestyle='--', alpha=0.6)
        safe_name = str(workload).replace('/', '_').replace('\\', '_').replace(' ', '_')
        save_fig(f'ipc_vs_l1d_associativity_{safe_name}.png')

def plot_ipc_vs_memdep(df):
    needed = {'memDep','IPC'}
    if not needed.issubset(df.columns): return
    g = df.groupby('memDep')['IPC'].mean().reset_index()
    plt.figure(figsize=(7,5))
    plt.bar(g['memDep'], g['IPC'])
    plt.title('Average IPC by memDep')
    plt.xlabel('memDep'); plt.ylabel('IPC')
    plt.grid(axis='y', linestyle='--', alpha=0.6)
    save_fig('ipc_vs_memdep.png')

def plot_workload_vs_ipc_off_vs_tournament(df):
    needed = {'workload','branchPred','IPC'}
    if not needed.issubset(df.columns): return
    base = df[['workload','branchPred','IPC']].copy()
    pivot = base.groupby(['workload','branchPred'], as_index=False)['IPC'].mean()
    workloads = sorted(base['workload'].astype(str).unique(), key=str.lower)
    _line_plot_off_vs_tournament(
        pivot_df=pivot, workloads=workloads, value_col='IPC',
        title='Workload vs IPC — OFF vs TOURNAMENT',
        ylabel='IPC', outfile='workload_vs_ipc_off_vs_tournament.png'
    )

def plot_workload_vs_bpred_miss_off_vs_tournament(df):
    needed = {'workload','branchPred','branch_mispred_rate'}
    if not needed.issubset(df.columns):
        print("Skipping misprediction plot (missing 'branch_mispred_rate')."); return
    base = df[['workload','branchPred','branch_mispred_rate']].dropna().copy()
    if base.empty:
        print("Skipping misprediction plot (no data)."); return
    pivot = base.groupby(['workload','branchPred'], as_index=False)['branch_mispred_rate'].mean()
    workloads = sorted(base['workload'].astype(str).unique(), key=str.lower)
    _line_plot_off_vs_tournament(
        pivot_df=pivot, workloads=workloads, value_col='branch_mispred_rate',
        title='Workload vs Branch Misprediction Rate — OFF vs TOURNAMENT',
        ylabel='Branch Misprediction Rate',
        outfile='workload_vs_bpred_miss_off_vs_tournament.png'
    )

# === Combined OFF + TOURNAMENT subplots with independent scaling + annotations ===
def plot_bpred_miss_off_tournament_subplots_annotated(df):
    needed = {'workload', 'branchPred', 'branch_mispred_rate'}
    if not needed.issubset(df.columns):
        print("Skipping: missing one of", needed); return
    g = (df.dropna(subset=['branch_mispred_rate'])
           .groupby(['workload', 'branchPred'], as_index=False)['branch_mispred_rate']
           .mean())
    if g['branch_mispred_rate'].max() <= 1.5:
        g['branch_mispred_rate'] = g['branch_mispred_rate'] * 100.0

    def _plot_for(pred, ax, color):
        sub = g[g['branchPred'] == pred].copy()
        if sub.empty:
            ax.set_visible(False); return
        workloads = sorted(sub['workload'].astype(str).unique(), key=str.lower)
        y = sub.set_index('workload').reindex(workloads)['branch_mispred_rate'].values
        ax.plot(workloads, y, marker='o', color=color)
        ax.set_title(f"{pred.upper()} — Branch Misprediction Rate by Workload")
        ax.set_ylabel("Misprediction rate (%)")
        ymin, ymax = float(np.nanmin(y)), float(np.nanmax(y))
        pad = (ymax - ymin) * 0.1 if ymax > ymin else max(ymax, 1.0) * 0.1
        ax.set_ylim(ymin - pad, ymax + pad)
        ax.grid(True, linestyle='--', alpha=0.6)
        ax.tick_params(axis='x', rotation=45)
        for i, val in enumerate(y):
            if np.isfinite(val):
                ax.text(i, val, f"{val:.2f}", ha="center", va="bottom", fontsize=8)

    fig, axes = plt.subplots(2, 1, figsize=(12, 10))
    _plot_for("off", axes[0], "tab:blue")
    _plot_for("tournament", axes[1], "tab:orange")
    axes[1].set_xlabel("Workload")
    plt.tight_layout()
    save_fig('bpred_miss_off_vs_tournament_ANNOTATED.png')

# ---------------- EXTRA TABLES & PLOTS YOU ASKED FOR ----------------
def _workloads_sorted(source):
    return sorted(source["workload"].astype(str).unique(), key=str.lower)

def _bar_by_workload(ax, workloads, values, title, ylabel):
    x = np.arange(len(workloads))
    ax.bar(x, values)
    ax.set_xticks(x)
    ax.set_xticklabels(workloads, rotation=45, ha="right")
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(axis="y", linestyle="--", alpha=0.6)

def _line_by_workload(ax, workloads, values, title, ylabel):
    x = np.arange(len(workloads))
    ax.plot(x, values, marker="o")
    ax.set_xticks(x)
    ax.set_xticklabels(workloads, rotation=45, ha="right")
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(True, linestyle="--", alpha=0.6)

def plot_ipc_by_workload(df):
    if "IPC" not in df.columns: 
        return
    g = df.groupby("workload", as_index=False)["IPC"].mean()
    w = _workloads_sorted(g)
    y = g.set_index("workload").reindex(w)["IPC"].values
    fig, ax = plt.subplots(figsize=(12,5))
    _bar_by_workload(ax, w, y, "IPC by Workload (bar)", "IPC")
    save_fig("ipc_by_workload_bar.png")
    fig, ax = plt.subplots(figsize=(12,5))
    _line_by_workload(ax, w, y, "IPC by Workload (line)", "IPC")
    save_fig("ipc_by_workload_line.png")

def plot_amat_grouped_and_lines(df):
    needed = {"L1D_AMAT","L1I_AMAT","L2_AMAT","workload"}
    if not needed.issubset(df.columns): return
    g = df.groupby("workload", as_index=False)[["L1D_AMAT","L1I_AMAT","L2_AMAT"]].mean()
    w = _workloads_sorted(g)
    L1D = g.set_index("workload").reindex(w)["L1D_AMAT"].values
    L1I = g.set_index("workload").reindex(w)["L1I_AMAT"].values
    L2  = g.set_index("workload").reindex(w)["L2_AMAT"].values
    bw = 0.25
    x = np.arange(len(w))
    fig, ax = plt.subplots(figsize=(12,6))
    ax.bar(x - bw, L1D, width=bw, label="L1D")
    ax.bar(x,       L1I, width=bw, label="L1I")
    ax.bar(x + bw,  L2,  width=bw, label="L2")
    ax.set_xticks(x); ax.set_xticklabels(w, rotation=45, ha="right")
    ax.set_title("AMAT by Workload and Cache Level (bar)")
    ax.set_ylabel("AMAT")
    ax.grid(axis="y", linestyle="--", alpha=0.6)
    ax.legend()
    save_fig("amat_by_workload_grouped_bar.png")
    fig, ax = plt.subplots(figsize=(12,6))
    ax.plot(w, L1D, marker="o", label="L1D")
    ax.plot(w, L1I, marker="o", label="L1I")
    ax.plot(w, L2,  marker="o", label="L2")
    ax.set_title("AMAT by Workload and Cache Level (lines)")
    ax.set_ylabel("AMAT")
    ax.grid(True, linestyle="--", alpha=0.6)
    ax.legend()
    save_fig("amat_by_workload_lines.png")

def plot_hit_rates_grouped_and_lines(df):
    needed = {"L1D_hit_rate","L1I_hit_rate","L2_hit_rate","workload"}
    if not needed.issubset(df.columns): return
    g = df.groupby("workload", as_index=False)[["L1D_hit_rate","L1I_hit_rate","L2_hit_rate"]].mean()
    w = _workloads_sorted(g)
    L1D = g.set_index("workload").reindex(w)["L1D_hit_rate"].values * 100.0
    L1I = g.set_index("workload").reindex(w)["L1I_hit_rate"].values * 100.0
    L2  = g.set_index("workload").reindex(w)["L2_hit_rate"].values * 100.0
    bw = 0.25
    x = np.arange(len(w))
    fig, ax = plt.subplots(figsize=(12,6))
    ax.bar(x - bw, L1D, width=bw, label="L1D")
    ax.bar(x,       L1I, width=bw, label="L1I")
    ax.bar(x + bw,  L2,  width=bw, label="L2")
    ax.set_xticks(x); ax.set_xticklabels(w, rotation=45, ha="right")
    ax.set_title("Cache Hit Rate by Workload and Level (bar)")
    ax.set_ylabel("Hit rate (%)")
    ax.grid(axis="y", linestyle="--", alpha=0.6)
    ax.legend()
    save_fig("hit_rates_grouped_bar.png")
    fig, ax = plt.subplots(figsize=(12,6))
    ax.plot(w, L1D, marker="o", label="L1D")
    ax.plot(w, L1I, marker="o", label="L1I")
    ax.plot(w, L2,  marker="o", label="L2")
    ax.set_title("Cache Hit Rate by Workload and Level (lines)")
    ax.set_ylabel("Hit rate (%)")
    ax.grid(True, linestyle="--", alpha=0.6)
    ax.legend()
    save_fig("hit_rates_lines.png")

def plot_speculation_success_failure(df):
    if "branch_mispred_rate" not in df.columns:
        print("No branch_mispred_rate; skipping speculation plots.")
        return
    mis = pd.to_numeric(df["branch_mispred_rate"], errors="coerce")
    if mis.dropna().max() > 1.5:
        mis = mis / 100.0
        df = df.copy()
        df["branch_mispred_rate"] = mis
    df["branch_success_rate"] = 1.0 - df["branch_mispred_rate"]
    g = df.groupby("workload", as_index=False)[["branch_mispred_rate","branch_success_rate"]].mean()
    w = _workloads_sorted(g)
    mis = g.set_index("workload").reindex(w)["branch_mispred_rate"].values * 100.0
    suc = g.set_index("workload").reindex(w)["branch_success_rate"].values * 100.0
    x = np.arange(len(w))
    fig, ax = plt.subplots(figsize=(12,6))
    ax.bar(x, suc, label="Success %")
    ax.bar(x, mis, bottom=suc, label="Failure (Mispred) %")
    ax.set_xticks(x); ax.set_xticklabels(w, rotation=45, ha="right")
    ax.set_title("Branch Prediction: Success vs Failure (stacked bar)")
    ax.set_ylabel("Percent of predictions (%)")
    ax.grid(axis="y", linestyle="--", alpha=0.6)
    ax.legend()
    save_fig("speculation_success_failure_stacked_bar.png")
    fig, ax = plt.subplots(figsize=(12,5))
    ax.plot(w, mis, marker="o")
    ax.set_title("Branch Misprediction Rate by Workload (line)")
    ax.set_ylabel("Misprediction rate (%)")
    ax.grid(True, linestyle="--", alpha=0.6)
    save_fig("speculation_mispred_line.png")

def plot_effective_stall_fraction(df):
    if "stall_frac_of_simTicks" not in df.columns:
        print("No stall_frac_of_simTicks; skipping stall plots.")
        return
    g = df.groupby("workload", as_index=False)["stall_frac_of_simTicks"].mean()
    w = _workloads_sorted(g)
    y = g.set_index("workload").reindex(w)["stall_frac_of_simTicks"].values * 100.0
    fig, ax = plt.subplots(figsize=(12,5))
    _bar_by_workload(ax, w, y, "Effective Stall Fraction by Workload (bar)", "Stall fraction (%)")
    save_fig("stall_fraction_by_workload_bar.png")
    if "issue" in df.columns:
        gi = df.groupby("issue", as_index=False)["stall_frac_of_simTicks"].mean().sort_values("issue")
        fig, ax = plt.subplots(figsize=(8,5))
        ax.plot(gi["issue"], gi["stall_frac_of_simTicks"] * 100.0, marker="o")
        ax.set_title("Effective Stall Fraction vs Issue Width (line)")
        ax.set_xlabel("Issue width"); ax.set_ylabel("Stall fraction (%)")
        ax.grid(True, linestyle="--", alpha=0.6)
        save_fig("stall_fraction_vs_issue_line.png")

def export_summary_tables(df):
    cols = [c for c in [
        "IPC","L1D_AMAT","L1I_AMAT","L2_AMAT",
        "L1D_hit_rate","L1I_hit_rate","L2_hit_rate",
        "branch_mispred_rate","stall_frac_of_simTicks"
    ] if c in df.columns]
    if not cols: 
        return
    tmp = df.copy()
    if "branch_mispred_rate" in tmp.columns and tmp["branch_mispred_rate"].dropna().max() > 1.5:
        tmp["branch_mispred_rate"] = tmp["branch_mispred_rate"] / 100.0
    if "branch_mispred_rate" in tmp.columns:
        tmp["branch_success_rate"] = 1.0 - tmp["branch_mispred_rate"]
    cols_w = [c for c in cols + ["branch_success_rate"] if c in tmp.columns]
    g = tmp.groupby("workload", as_index=False)[cols_w].mean()
    for c in ["L1D_hit_rate","L1I_hit_rate","L2_hit_rate","branch_mispred_rate","branch_success_rate","stall_frac_of_simTicks"]:
        if c in g.columns: g[c] = g[c] * 100.0
    g.rename(columns={
        "L1D_hit_rate":"L1D_hit_%","L1I_hit_rate":"L1I_hit_%","L2_hit_rate":"L2_hit_%",
        "branch_mispred_rate":"mispred_%","branch_success_rate":"predict_success_%",
        "stall_frac_of_simTicks":"stall_frac_%"
    }, inplace=True)
    g.to_csv(OUTPUT_DIR / "table_workload_summary.csv", index=False)
    if "branchPred" in tmp.columns:
        gp = tmp.groupby("branchPred", as_index=False)[cols_w].mean()
        for c in ["L1D_hit_rate","L1I_hit_rate","L2_hit_rate","branch_mispred_rate","branch_success_rate","stall_frac_of_simTicks"]:
            if c in gp.columns: gp[c] = gp[c] * 100.0
        gp.rename(columns={
            "L1D_hit_rate":"L1D_hit_%","L1I_hit_rate":"L1I_hit_%","L2_hit_rate":"L2_hit_%",
            "branch_mispred_rate":"mispred_%","branch_success_rate":"predict_success_%",
            "stall_frac_of_simTicks":"stall_frac_%"
        }, inplace=True)
        gp.to_csv(OUTPUT_DIR / "table_predictor_summary.csv", index=False)

# ========== RUN ==========
if __name__ == '__main__':
    print(f"Saving plots to: {OUTPUT_DIR.resolve()}")
    plot_amat_logscale(df.copy())
    plot_ipc_vs_rob(df.copy())
    plot_ipc_vs_width(df.copy())
    plot_mpki_by_level(df.copy())
    plot_bp_miss_vs_ipc(df.copy())
    plot_stall_by_bp(df.copy())
    plot_stall_vs_width(df.copy())
    plot_hitrate_by_workload(df.copy())
    plot_ipc_vs_l1d_associativity(df.copy())  # one PNG per workload
    plot_ipc_vs_memdep(df.copy())
    plot_workload_vs_ipc_off_vs_tournament(df.copy())
    plot_workload_vs_bpred_miss_off_vs_tournament(df.copy())
    plot_bpred_miss_off_tournament_subplots_annotated(df.copy())

    # === NEW: plots & tables for IPC, AMAT, hit rates, speculation, stall ===
    plot_ipc_by_workload(df.copy())
    plot_amat_grouped_and_lines(df.copy())
    plot_hit_rates_grouped_and_lines(df.copy())
    plot_speculation_success_failure(df.copy())
    plot_effective_stall_fraction(df.copy())
    export_summary_tables(df.copy())

    print("Done.")
