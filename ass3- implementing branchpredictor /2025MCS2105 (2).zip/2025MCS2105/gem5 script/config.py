#!/usr/bin/env python3
import os
import argparse
import m5
from pathlib import Path
from gem5.components.boards.simple_board import SimpleBoard
from gem5.components.cachehierarchies.classic.private_l1_shared_l2_cache_hierarchy import  (
    PrivateL1SharedL2CacheHierarchy as _BaseH,
)
from gem5.components.memory.single_channel import SingleChannelDDR4_2400
from gem5.resources.resource import BinaryResource
from gem5.simulate.simulator import Simulator
from gem5.isas import ISA
from gem5.components.processors.base_cpu_core import BaseCPUCore
from gem5.components.processors.base_cpu_processor import BaseCPUProcessor
from m5.objects import DerivO3CPU, BiModeBP, GshareBP, LocalBP, TournamentBP, NullBP
from m5.objects import StridePrefetcher, TaggedPrefetcher, AMPMPrefetcher, LRURP, FIFORP,RandomRP
from m5.params import NULL


class PrivateL1SharedL2CacheHierarchyWithPF(_BaseH):
    def __init__(self, *args,
                #  l1i_prefetcher=None,                 
                #  l1d_prefetcher=StridePrefetcher(),   
                #  l2_prefetcher=TaggedPrefetcher(),    
                 l1i_rp=LRURP(), l1d_rp=LRURP(), l2_rp=LRURP(),
                 **kwargs):
        super().__init__(*args, **kwargs)
        # self._l1i_pf = l1i_prefetcher
        # self._l1d_pf = l1d_prefetcher
        # self._l2_pf  = l2_prefetcher
        self._l1i_rp = l1i_rp
        self._l1d_rp = l1d_rp
        self._l2_rp  = l2_rp

    def incorporate_cache(self, board):
        
        super().incorporate_cache(board)  # builds self.l1icaches/self.l1dcaches/self.l2cache
        # self.l1icaches[0].prefetcher = self._l1i_pf
        # self.l1dcaches[0].prefetcher = self._l1d_pf
        # self.l2cache.prefetcher      = self._l2_pf
        self.l1icaches[0].replacement_policy = self._l1i_rp
        self.l1dcaches[0].replacement_policy = self._l1d_rp
        self.l2cache.replacement_policy = self._l2_rp







# defining dictionary for branch predictor
bp_dict = {
    "off" : NullBP(),
    "local": LocalBP(),
    "tournament": TournamentBP(choicePredictorSize=4096),
    "gshare": GshareBP(globalPredictorSize=12, PHTPredictorSize=8192),
    "bimode": BiModeBP(globalPredictorSize=4096, globalCtrBits=2),
}
pref= {
    "stride" : StridePrefetcher(),
    "tagged" : TaggedPrefetcher()
}

memd={
    "on": 1_000_000,
    "off": 1

}

replcament_s = {
    "lru": LRURP(),
    "fifo": FIFORP()
}
class MyOutOfOrderCore(BaseCPUCore):
    def __init__(self, width=8, rob_size=192):
        super().__init__(DerivO3CPU(), ISA.X86)
        self.core.fetchWidth = width
        self.core.decodeWidth = width
        self.core.renameWidth = width
        self.core.issueWidth = width
        self.core.wbWidth = width
        self.core.commitWidth = width

        self.core.numROBEntries = rob_size
       

        # Default branch predictor (you can change via code below)
        self.core.branchPred = LocalBP()
        # Examples (uncomment one to use):
        # self.core.branchPred = TournamentBP(choicePredictorSize = 4096)
        # self.core.branchPred = GshareBP(globalPredictorSize = 12, PHTPredictorSize = 8192)
        # self.core.branchPred = BiModeBP(globalPredictorSize=4096, globalCtrBits=2)

class MyOutOfOrderProcessor(BaseCPUProcessor):
    def __init__(self, width=8, rob_size=192):
        cores = [MyOutOfOrderCore(width, rob_size)]
        super().__init__(cores)



# passing arguments
parser = argparse.ArgumentParser()
parser.add_argument("--bina")
parser.add_argument("--options", nargs="*")
parser.add_argument("--bp")
parser.add_argument("--rob", type= int)
parser.add_argument("--iss", type= int)
parser.add_argument("--l1a", type= int)
parser.add_argument("--l2a", type= int)
parser.add_argument("--l1s")
parser.add_argument("--l2s")
parser.add_argument("--pr")
parser.add_argument("--rep")
parser.add_argument("--mp")


# parser.add_argument("--iq", type= int)



# args = parser.parse_args()
args = parser.parse_args()
binary_path = args.bina
binary_args = args.options
bp_key = args.bp
rob_value = args.rob
isue = args.iss
l1_A=args.l1a
l2_A=args.l2a
l1_S=args.l1s
l2_S=args.l2s 
preftch = args.pr
replacement_value = args.rep
memdep = args.mp

# iq_entry  = args.iq



print(f"[CONFIG] Arguments : {isue}")
print(f"[CONFIG] Arguments : {bp_key}")
print(f"[CONFIG] Arguments : {rob_value}")
print(f"[CONFIG] Arguments : {l1_A}")
print(f"[CONFIG] Arguments : {l2_A}")
print(f"[CONFIG] Arguments : {l1_S}")
print(f"[CONFIG] Arguments : {l2_S}")
print(f"[CONFIG] Arguments : {pref}")
print(f"[CONFIG] Arguments : {replacement_value}")
print(f"[CONFIG] Arguments : {memdep}")



# changing processor atttributes
processor = MyOutOfOrderProcessor(width=8, rob_size=192)

bp_constructor = bp_dict.get(bp_key)
processor.cores[0].core.branchPred = bp_constructor()
processor.cores[0].core.numROBEntries = rob_value
processor.cores[0].core.fetchWidth = isue
processor.cores[0].core.issueWidth = isue

# for mem dep predictor

# processor.cores[0].core.SSITSize = 1
# processor.cores[0].core.LFSTSize = 1
processor.cores[0].core.store_set_clear_period = memd.get(memdep)


# processor.cores[0].core.SSITSize = 4096
# processor.cores[0].core.LFSTSize = 1024
# processor.cores[0].core.store_set_clear_period = 100000  # load/store insts


# processor.cores[0].core.numIQEntries = iq_entry
processor.cores[0].core.max_insts_any_thread = 100_000_000


memory = SingleChannelDDR4_2400(size="2GB")
cache_hierarchy = PrivateL1SharedL2CacheHierarchyWithPF(
   l1i_size=l1_S, l1i_assoc=l1_A,
    l1d_size=l1_S, l1d_assoc=l1_A,
    l2_size=l2_S, l2_assoc=l2_A,
    # l1i_prefetcher= pref.get(preftch)(),
    # l1d_prefetcher=pref.get(preftch)(),
    # l2_prefetcher=pref.get(preftch)(),
    l1i_rp=replcament_s.get(replacement_value)(),
    l1d_rp=replcament_s.get(replacement_value)(),
    l2_rp=replcament_s.get(replacement_value)(),
)



board = SimpleBoard(
    processor=processor,
    memory=memory,
    cache_hierarchy=cache_hierarchy,
    clk_freq="3GHz",
)

if binary_args == "s":
    board.set_se_binary_workload(BinaryResource(binary_path))
else:
    board.set_se_binary_workload(BinaryResource(binary_path), arguments=binary_args)

# binary = BinaryResource("./compute")
# board.set_se_binary_workload(binary)



sim = Simulator(board=board)
sim.run()


# need to implement prefetcher as a variable in this
# need to implement replacement policy as a var in this 
