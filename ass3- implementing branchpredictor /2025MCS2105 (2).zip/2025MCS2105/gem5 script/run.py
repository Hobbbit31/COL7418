#!/usr/bin/env python3
import os

import subprocess
from pathlib import Path

# Paths
GEM5 = os.path.expanduser("~/gem5/build/X86/gem5.opt")
CONFIG = os.path.expanduser("~/Ass_3/script/config.py")
WORK = os.path.expanduser("~/Ass_3/script")
RESULTS = os.path.expanduser("~/Ass_3/create")
Path(RESULTS).mkdir(parents=True, exist_ok=True)


# defining variables, "bimode",
BPS = [ "off" , "tournament"]
mem = ["on", "off"]

# 256, 256,512
rob_vals = [ 128,256]
# 8  
issue = [4,8]
# "32kB" 
l1_size = ["16kB" ,"32kB"]
# 2,8 4 ,
l1_ass = [2,4]
# 4,16 8 ,
l2_ass = [ 8,16]
# "256kB" 
l2_size =[ "256kB", "512kB"]

# , "tagged"

prefet=["stride" ]
# 
repl = ["lru" , "fifo" ]
# num_IQentres = [64,128]

# defining workload
# worads = {
#     "quicksort_small": {
#         "bin": os.path.join(WORK, "automotive/qsort/qsort_small"),
#         "options": os.path.join(WORK, "automotive/qsort/input_small.dat")
#     },
#     "quicksort_large": {
#         "bin": os.path.join(WORK, "automotive/qsort/qsort_large"),
#         "options": os.path.join(WORK, "automotive/qsort/input_large.dat")
#     },
#     "dijkstra_small": {
#         "bin": os.path.join(WORK, "network/dijkstra/dijkstra_small"),
#         "options": os.path.join(WORK, "network/dijkstra/input.dat")
#     },
#     # "dijkstra_large": {
#     #     "bin": os.path.join(WORK, "network/dijkstra/dijkstra_large"),
#     #     "options": os.path.join(WORK, "network/dijkstra/input.dat")
#     # },
#     "basicmath":{
#         "bin":os.path.join(WORK, "automotive/basicmath/basicmath_small"),
#         "options":"s"
#     },
#     # "basicmath":{
#     #     "bin":os.path.join(WORK, "automotive/basicmath/basicmath_large"),
#     #     "options":"s"
#     # }
#     "fft":{
#         "bin":os.path.join(WORK, "telecomm/FFT/fft"),
#         "options": "s"
#     }

# }

# Workload

workloads = {
    "compute":{
        "bin":os.path.join(WORK, "compute"),
        "options": "s"
    },
    "link":{
        "bin":os.path.join(WORK, "link"),
        "options": "s"
    },
    "memory":{
        "bin":os.path.join(WORK, "memory"),
        "options": "s"
    }
}
cnt = 0

# running for each variable and workload
for pr in prefet:
    for r in repl:
        for bp in BPS:
            for iss in issue:
                for rob in rob_vals:
                    for l1s in l1_size:
                        for l2s in l2_size:
                            for l1a in l1_ass:
                                for l2a in l2_ass:
                                    for mdp in mem:
                                        for name, wl in workloads.items():
                                            bina = wl["bin"]
                                            opt = wl["options"]

                                            stats_file = os.path.join(RESULTS, f"stats_{bp}_ROB{rob}_issue_{iss}_l1A_{l1a}_l2A_{l2a}_l1s_{l1s}_l2s_{l2s}_prefetcher_{pr}_repl_{r}_workload_{name}_memDep_{mdp}.txt")
                                            print(f"[INFO] Stats -> {stats_file}")

                                            cmd = [
                                                GEM5,
                                                f"--stats-file={stats_file}",
                                                CONFIG,
                                                # "--cmd", HELLO_BIN,                               
                                                "--bp",bp,
                                                "--bina", bina,
                                                "--options", opt,
                                                "--iss",str(iss),
                                                "--rob",str(rob),
                                                "--l1a",str(l1a),
                                                "--l2a",str(l2a),
                                                "--l1s",l1s,
                                                "--l2s",l2s,
                                                "--pr",pr,
                                                "--rep",r,
                                                "--mp",mdp                                           
                                            ]
                                            print("Running:", " ".join(cmd))
                                            subprocess.run(cmd, check=True)
                                            print(cnt)
                                            cnt = cnt+1
                            

print("\n[INFO] All runs complete. Stats files saved in", RESULTS)

print("\n[INFO] All runs complete. Stats files saved in", RESULTS)
