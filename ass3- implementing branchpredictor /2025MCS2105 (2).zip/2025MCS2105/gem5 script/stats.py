#!/usr/bin/env python3
"""
Extract parameters from gem5 stats *filenames* AND compute *metrics* from file contents.

Expected filename pattern (examples):
- stats_off_ROB128_issue_4_l1A_2_l2A_8_l1s_16kB_l2s_256kB_prefetcher_stride_repl_fifo_workload_compute_memDep_off.txt
- stats_tournament_ROB128_issue_8_l1A_2_l2A_8_l1s_16kB_l2s_256kB_prefetcher_stride_repl_lru_workload_link_memDep_off.txt

Outputs columns in this order:
(branchPred, issue, ROB, l1A, l2A, l1s, l2s, prefetcher, repl, workload, memDep, filename)
+ metrics:
IPC, L1D_hit_rate, L1I_hit_rate, L2_hit_rate,
L1D_MPKI, L1I_MPKI, L2_MPKI,
L1D_AMAT, L1I_AMAT, L2_AMAT,
branch_mispred_rate, memdep_success, memdep_fail,
pipeline_flushes, stall_cycles_proxy, stall_frac_of_simTicks,
energy_L1D_proxy, energy_L1I_proxy, energy_L1_proxy,
energy_L2_proxy, energy_DRAM_proxy, energy_weighted_proxy,
energy_DRAM
"""

import re
import csv
import sys
import os
import math
import argparse
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

# ---------------- Tunables ----------------
CPU_CYCLES_PER_TICK = 1.0
HIT_COST_CYCLES     = 1.0
ENERGY_WEIGHTS      = {"L1": 1.0, "L2": 10.0, "DRAM": 200.0}

# ---------------- Filename regex ----------------
# Flexible regex: tolerates "issue_4" or "issue4" etc.
PATTERN = re.compile(r"""
^stats_(?P<branchPred>[^_]+)
 _ROB(?P<ROB>\d+)
 _issue_?(?P<issue>\d+)
 _l1A_?(?P<l1A>\d+)
 _l2A_?(?P<l2A>\d+)
 _l1s_?(?P<l1s>\d+kB)
 _l2s_?(?P<l2s>\d+kB)
 _prefetcher_(?P<prefetcher>[^_]+)
 _repl_(?P<repl>[^_]+)
 _workload_(?P<workload>[^_]+)
 _memDep_(?P<memDep>[^_]+)
$""", re.X)

PARAM_COLUMNS = ["branchPred","issue","ROB","l1A","l2A","l1s","l2s","prefetcher","repl","workload","memDep","filename"]

# ---------------- Stats helpers ----------------
def read_stats(path: Path) -> Dict[str, float]:
    d: Dict[str, float] = {}
    with open(path, "r", errors="ignore") as f:
        for line in f:
            s = line.split("#", 1)[0].strip()
            if not s:
                continue
            parts = s.split()
            if len(parts) < 2:
                continue
            key, val = parts[0], parts[1]
            try:
                d[key] = float(val)
            except:
                pass
    return d

def first(stats: Dict[str, float], keys: Iterable[str]) -> float:
    for k in keys:
        v = stats.get(k, float("nan"))
        if not math.isnan(v):
            return v
    return float("nan")

def rate(n, d):
    return (n / d) if d and not math.isnan(n) else float("nan")

def mpki(m, insts):
    return (m * 1000.0 / insts) if insts and not math.isnan(m) else float("nan")

def cache_bundle(stats: Dict[str, float], prefixes: Iterable[str]) -> Tuple[float,float,float,float]:
    for base in prefixes:
        hits = first(stats, [f"{base}.overallHits::total", f"{base}.demandHits::total"])
        miss = first(stats, [f"{base}.overallMisses::total", f"{base}.demandMisses::total"])
        acc  = first(stats, [f"{base}.overallAccesses::total", f"{base}.demandAccesses::total"])
        amlt = first(stats, [f"{base}.overallAvgMissLatency::total", f"{base}.demandAvgMissLatency::total"])
        # if anything exists, return this bundle
        if not (math.isnan(acc) and math.isnan(hits) and math.isnan(miss)):
            return hits, miss, acc, amlt
    return float("nan"), float("nan"), float("nan"), float("nan")

def amat_proxy(hits, misses, accesses, avg_miss_lat_ticks):
    if not accesses or math.isnan(avg_miss_lat_ticks):
        return float("nan")
    avg_miss_lat_cycles = avg_miss_lat_ticks / CPU_CYCLES_PER_TICK
    return (hits * HIT_COST_CYCLES + misses * avg_miss_lat_cycles) / accesses

def compute_memdep_proxies(stats: Dict[str, float]) -> Dict[str, float]:
    ins_ld = sum(v for k, v in stats.items() if "MemDepUnit__" in k and k.endswith(".insertedLoads"))
    ins_st = sum(v for k, v in stats.items() if "MemDepUnit__" in k and k.endswith(".insertedStores"))
    con_ld = sum(v for k, v in stats.items() if "MemDepUnit__" in k and k.endswith(".conflictingLoads"))
    con_st = sum(v for k, v in stats.items() if "MemDepUnit__" in k and k.endswith(".conflictingStores"))
    inserted, conflicts = ins_ld + ins_st, con_ld + con_st
    return {
        "memdep_success": inserted - conflicts if inserted else float("nan"),
        "memdep_fail": conflicts if inserted else float("nan"),
    }

def compute_metrics(stats: Dict[str, float]) -> Dict[str, float]:
    out: Dict[str, float] = {}

    # --- IPC (prefer direct stat) ---
    ipc_val = first(stats, [
        "board.processor.cores.core.ipc",
        "system.cpu.ipc",
    ])
    if not math.isnan(ipc_val):
        out["IPC"] = ipc_val
    else:
        # fallbacks only if needed
        simInsts  = stats.get("simInsts", float("nan"))
        simTicks  = stats.get("simTicks", float("nan"))
        numCycles = first(stats, ["system.cpu.numCycles", "board.processor.cores.core.numCycles"])
        if numCycles and not math.isnan(simInsts):
            out["IPC"] = simInsts / numCycles
        elif simTicks and not math.isnan(simInsts):
            out["IPC"] = simInsts / (simTicks / CPU_CYCLES_PER_TICK)
        else:
            out["IPC"] = float("nan")

    # Cache groups (Classic + Board prefixes)
    L1D = ["system.l1d", "board.cache_hierarchy.l1dcaches"]
    L1I = ["system.l1i", "board.cache_hierarchy.l1icaches"]
    L2  = ["system.l2",  "board.cache_hierarchy.l2cache"]

    l1d_h, l1d_m, l1d_a, l1d_ml = cache_bundle(stats, L1D)
    l1i_h, l1i_m, l1i_a, l1i_ml = cache_bundle(stats, L1I)
    l2_h,  l2_m,  l2_a,  l2_ml  = cache_bundle(stats, L2)

    simInsts = stats.get("simInsts", float("nan"))
    out.update({
        "L1D_hit_rate": rate(l1d_h, l1d_a),
        "L1I_hit_rate": rate(l1i_h, l1i_a),
        "L2_hit_rate":  rate(l2_h,  l2_a),
        "L1D_MPKI": mpki(l1d_m, simInsts),
        "L1I_MPKI": mpki(l1i_m, simInsts),
        "L2_MPKI":  mpki(l2_m,  simInsts),
        "L1D_AMAT": amat_proxy(l1d_h, l1d_m, l1d_a, l1d_ml),
        "L1I_AMAT": amat_proxy(l1i_h, l1i_m, l1i_a, l1i_ml),
        "L2_AMAT":  amat_proxy(l2_h,  l2_m,  l2_a,  l2_ml),
    })

    # Branch misprediction rate
    lookups = first(stats, ["system.cpu.branchPred.lookups", "board.processor.cores.core.branchPred.lookups"])
    mispred = first(stats, ["system.cpu.branchPred.condIncorrect", "board.processor.cores.core.branchPred.condIncorrect"])
    out["branch_mispred_rate"] = rate(mispred, lookups)

    # MemDep proxies
    out.update(compute_memdep_proxies(stats))

    # Pipeline flushes
    out["pipeline_flushes"] = first(stats, [
        "board.processor.cores.core.commit.commitSquashedInsts",
        "system.cpu.commitSquashedInsts",
        "board.processor.cores.core.commitSquashedInsts",
    ])

    # Stall cycles (proxy)
    l1d_lat = first(stats, [p + ".demandMshrMissLatency::total" for p in L1D])
    l1i_lat = first(stats, [p + ".demandMshrMissLatency::total" for p in L1I])
    l2_lat  = first(stats, [p + ".demandMshrMissLatency::total" for p in L2])
    total_lat = sum(x for x in (l1d_lat, l1i_lat, l2_lat) if not math.isnan(x))
    out["stall_cycles_proxy"] = total_lat / CPU_CYCLES_PER_TICK if total_lat else float("nan")
    simTicks = stats.get("simTicks", float("nan"))
    out["stall_frac_of_simTicks"] = (total_lat / simTicks) if simTicks and total_lat else float("nan")

    # ----------------- Energy (proxies + true DRAM) -----------------
    l1d_acc = first(stats, [p + ".overallAccesses::total" for p in L1D])
    l1i_acc = first(stats, [p + ".overallAccesses::total" for p in L1I])
    l2_acc  = first(stats, [p + ".overallAccesses::total" for p in L2])

    l1d_cnt = 0 if math.isnan(l1d_acc) else l1d_acc
    l1i_cnt = 0 if math.isnan(l1i_acc) else l1i_acc
    l2_cnt  = 0 if math.isnan(l2_acc)  else l2_acc

    dram_r = first(stats, ["system.mem_ctrl.readReqs",  "board.memories.dram0.readReqs"])
    dram_w = first(stats, ["system.mem_ctrl.writeReqs", "board.memories.dram0.writeReqs"])
    dram_cnt = (0 if math.isnan(dram_r) else dram_r) + (0 if math.isnan(dram_w) else dram_w)

    out["energy_L1D_proxy"] = l1d_cnt
    out["energy_L1I_proxy"] = l1i_cnt
    out["energy_L1_proxy"]  = l1d_cnt + l1i_cnt
    out["energy_L2_proxy"]  = l2_cnt
    out["energy_DRAM_proxy"]= dram_cnt

    out["energy_weighted_proxy"] = (
        ENERGY_WEIGHTS["L1"]  * out["energy_L1_proxy"] +
        ENERGY_WEIGHTS["L2"]  * out["energy_L2_proxy"] +
        ENERGY_WEIGHTS["DRAM"]* out["energy_DRAM_proxy"]
    )

    # True DRAM energy (sum per-rank totalEnergy)
    dram_energy_sum = sum(
        v for k, v in stats.items()
        if k.startswith("board.memory.mem_ctrl.dram.rank") and k.endswith(".totalEnergy")
    )
    if not dram_energy_sum or math.isnan(dram_energy_sum):
        dram_energy_sum = first(stats, [
            "board.memory.dram.energy",
            "system.mem_ctrl.dram.energy"
        ])
    out["energy_DRAM"] = dram_energy_sum

    return out

# Metrics column order for CSV
METRIC_COLUMNS = [
    "IPC",
    "L1D_hit_rate","L1I_hit_rate","L2_hit_rate",
    "L1D_MPKI","L1I_MPKI","L2_MPKI",
    "L1D_AMAT","L1I_AMAT","L2_AMAT",
    "branch_mispred_rate",
    "memdep_success","memdep_fail",
    "pipeline_flushes",
    "stall_cycles_proxy","stall_frac_of_simTicks",
    "energy_L1D_proxy","energy_L1I_proxy","energy_L1_proxy",
    "energy_L2_proxy","energy_DRAM_proxy","energy_weighted_proxy",
    "energy_DRAM"
]

# ---------------- File gathering ----------------
def gather_files(files, directory):
    paths: List[Path] = []
    if files:
        for f in files:
            paths.extend(Path().glob(f))  # allow globs from CLI
    if directory:
        p = Path(directory)
        if not p.exists():
            sys.exit(f"[error] Directory not found: {directory}")
        # recursively include anything named stats_*.txt
        paths.extend(p.rglob("stats_*.txt"))
    if not files and not directory:
        # default: current dir
        paths.extend(Path().glob("stats_*.txt"))
    # De-duplicate and ensure only files
    uniq = []
    seen = set()
    for path in paths:
        path = path.resolve()
        if path.is_file() and path not in seen:
            uniq.append(path)
            seen.add(path)
    return uniq

# ---------------- Main ----------------
def parse_name(path: Path) -> Optional[Dict[str, str]]:
    name = path.stem  # drop .txt
    m = PATTERN.match(name)
    if not m:
        return None
    d = m.groupdict()
    # Normalize numeric fields to int strings (optional)
    for k in ["issue","ROB","l1A","l2A"]:
        d[k] = str(int(d[k]))
    d["filename"] = path.name
    return d

def main():
    ap = argparse.ArgumentParser(description="Extract gem5 filename params + metrics into CSV.")
    ap.add_argument("files", nargs="*", help="Specific files or globs (e.g., stats_*.txt)")
    ap.add_argument("--dir", help="Directory to scan recursively for stats_*.txt")
    ap.add_argument("--out", "-o", help="Output CSV file (default: print to stdout)")
    args = ap.parse_args()

    paths = gather_files(args.files, args.dir)
    if not paths:
        sys.exit("[error] No matching files found.")

    rows = []
    skipped = []
    for p in sorted(paths):
        params = parse_name(p)
        if params is None:
            skipped.append(p.name)
            # still compute metrics and include filename so you don’t lose data
            params = {k: "" for k in PARAM_COLUMNS}
            params["filename"] = p.name

        stats = read_stats(p)
        metrics = compute_metrics(stats)

        # ensure all columns exist
        row = {c: params.get(c, "") for c in PARAM_COLUMNS}
        for c in METRIC_COLUMNS:
            row[c] = metrics.get(c, float("nan"))
        rows.append(row)

    # Write CSV
    fieldnames = PARAM_COLUMNS + METRIC_COLUMNS
    if args.out:
        with open(args.out, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(rows)
        print(f"[ok] Wrote {len(rows)} rows to {args.out}")
    else:
        w = csv.DictWriter(sys.stdout, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)

    if skipped:
        print(f"[warn] Skipped filename-parse (pattern mismatch): {len(skipped)}", file=sys.stderr)
        for name in skipped[:10]:
            print(f"  - {name}", file=sys.stderr)
        if len(skipped) > 10:
            print(f"  ... and {len(skipped)-10} more", file=sys.stderr)

if __name__ == "__main__":
    main()
